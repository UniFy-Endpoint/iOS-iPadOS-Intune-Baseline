# iOS/iPadOS Intune Baseline — Project Backup

## 1. Project Overview

| Property | Value |
|---|---|
| Project | iOS/iPadOS Microsoft Intune Baseline |
| Author | Sr. Modern Work Consultant |
| CIS Reference | CIS Apple iOS/iPadOS 26 Benchmark v1.0.0 |
| Microsoft Reference | iOS/iPadOS Security Configuration Framework (updated April 2026) |
| Last Updated | June 1 2026 |
| Status | Session 20 complete — 44 JSON files |
| Total JSON Files | 44 (22 SC + 4 CP + 1 APP + 13 ACP-MDM + 2 Defender + 2 CA) |
| Tool for Import | IntuneManagement-Master |

## 2. Session History

### Session 19 — June 1 2026

**Apple Intelligence compliance gap fix + Documentation source attribution (Nick Benton feedback)**

**Trigger:** LinkedIn comment from Nick Benton (Principal Cloud Endpoint Consultant) requesting clarity on which settings come from CIS, which from Microsoft Framework, and which are experience-based operational decisions.

**Catalog audit (SuportFiles\ screenshots confirmed):**
- Intelligence Settings subcategory has 18 settings; current JSON only uses 9
- 3 CIS L1 gaps confirmed: Notes Transcription (Section 3.10.2), Notes Transcription Summary (Section 3.10.2), Mail Summary (Section 3.10.3)
- 2 additional operational settings confirmed available: Mail Smart Replies, Safari AI Summary (Intelligence)
- Additional catalog items noted but deferred: sirisettings_forceprofanityfilter, externalintelligencesettings_allowedworkspaceids, Keyboard Settings group (8 settings)

**Documentation fixes (Track B — completed this session):**
- `iOS_CIS-Microsoft_Recommended_Settings_Guide.md` v1.0 → v1.1:
  - Section 2 renamed to "Security Levels & Source Classification"
  - Added Section 2.3 Setting Source Classification (source legend with 7 label types)
  - Added Section 2.4 Policy Architecture (absorbed old Section 3)
  - Added new Section 3 "Compliance Reference" with 6 sub-sections:
    - Section 3.1 Intentional Deviations Registry (8 documented deviations including Apple Intelligence BYOD gap)
    - Section 3.2 CIS L1 Controls — BYOD
    - Section 3.3 CIS L1 Controls — Corporate
    - Section 3.4 CIS L2 Controls — Corporate
    - Section 3.5 Microsoft Security Framework Settings
    - Section 3.6 Operational / Best-Practice Settings
  - Renamed "CIS Level" column → "Level / Source" throughout all 30+ settings tables
  - Replaced "Corporate"/"BYOD"/"N/A" labels → "Operational" in Level/Source column
  - Writing Tools row: changed from "Corporate" to "CIS Section 3.10.4*" (deviation marker)
  - iCloud Private Relay: corrected from "L1"/"L2" to "CIS Additional + MS-L1"/"CIS Additional"
  - Mail Privacy Protection: corrected from "L1" to "CIS Additional" (CIS Section 4.6 is an "Additional Recommendation", not L1/L2)
  - Section 4.14 (Apple Intelligence Corporate): added 5 pending rows (Notes Transcription, Notes Summary, Mail Summary, Mail Smart Replies, Safari Summary Intelligence), DDM note, deviation footnote
  - Section 5.7 renamed to "Apple Intelligence & Siri — BYOD (DDM Gap)": full expansion with CIS Section references, DDM root cause, compensating controls, monitoring recommendation
- `SETTINGSOUTPUT.md`:
  - Policy 1 description updated to accurately describe all 3 setting groups
  - Writing Tools Notes corrected: "CIS does not require blocking" → "Intentional deviation from CIS Section 3.10.4 L1"
  - Added "Pending JSON update" block with 5 settings to add (TBC settingDefinitionIds)
  - Siri Settings Notes updated to distinguish CIS L1 from Operational
  - Added new "CIS Compliance Gaps — Apple Intelligence BYOD" section before Baseline Compliance Assessment
  - Updated CIS L1 Corporate and BYOD coverage percentages
- `CLAUDE.md`:
  - intelligencesettings_allowwritingtools note corrected (removed "CIS does not require blocking")
  - Added Intelligence Settings Apps sub-groups note with inferred settingDefinitionIds (TBC from Intune export)
  - Added catalog-available but not configured: sirisettings_forceprofanityfilter, externalintelligencesettings_allowedworkspaceids, Keyboard Settings group
  - Updated Siri Settings notes to distinguish CIS L1 from Operational
  - Updated Key Decisions: Writing Tools deviation, Keyboard Settings deferred, other catalog items noted
  - Corrected Naming Convention note for Apple Intelligence
- `iOS_iPadOS_BYOD_Deployment_Guide.md`: expanded Apple Intelligence note with CIS Section 2.9.1–2.9.4 references, CIS compliance impact, compensating controls
- `README.md`: updated Apple Intelligence BYOD design decision with CIS Section references and gap documentation pointer

**Documentation errors found and corrected:**
- SETTINGSOUTPUT.md Policy 1 Notes for Writing Tools incorrectly said "CIS does not require blocking" — CIS Section 3.10.4 explicitly requires it disabled (L1)
- iOS_CIS-Microsoft_Recommended_Settings_Guide.md labeled iCloud Private Relay as "L1" — it's CIS Section 4.5 "Additional Recommendation" (not in L1/L2 profile)
- iOS_CIS-Microsoft_Recommended_Settings_Guide.md labeled Mail Privacy Protection as "L1" — it's CIS Section 4.6 "Additional Recommendation"
- Policy 1 JSON description only mentioned Siri, not the 11 other settings

**Pending (Track A — awaiting Intune portal export):**
- Add 5 new settings to Apple Intelligence & Siri Corporate JSON: Notes Transcription, Notes Transcription Summary, Mail Summary, Mail Smart Replies, Safari Summary (Intelligence Settings)
- Update CLAUDE.md confirmed settingDefinitionIds after export
- JSON total: 44 (no change until Track A complete)

**LinkedIn reply drafted** for Nick Benton — see iOS_CIS-Microsoft_Recommended_Settings_Guide.md plan file for text.

---

### Session 20 — June 1 2026

**iOS_CIS-Microsoft_Recommended_Settings_Guide.md v1.1 → v1.2: Section 3 deduplication and CIS level corrections**

**Section 3.1 Deviations Registry compacted:**
- Merged "Require Alphanumeric Passcode (Corporate)" and "Require Alphanumeric Passcode (BYOD)" into one row (Corporate / BYOD)
- Merged "Writing Tools (Corporate)" and "Writing Tools (MAM — BYOD)" into one row (Corporate / BYOD)
- Reduced from 8 rows to 6 rows; columns reduced from 7 to 6 (Section Reference dropped; Justification + Compensating Control merged into Notes)

**Section 3.2 (CIS L1) duplicates fixed:**
- "VPN Configured" — merged 2 rows (Corporate + BYOD) into 1 row; delivery mechanism noted in Notes column
- Apple Intelligence BYOD DDM gap — collapsed 4 identical "Not applied — DDM gap" rows into 1 row
- "Block Screenshots" (`allowscreenshot=false`) removed — confirmed L2 not L1 (per-policy tables in Sections 4–5 are authoritative); row retained correctly in Section 3.3
- "Safari Cookies = Current Website Only" (`safari_acceptcookies=1`) removed — confirmed L2 not L1; row in Section 3.3 updated to Corporate / BYOD (BYOD Safari policy also applies this at L2)

**Section 3.3 (CIS L2) updated:**
- "Block Third-Party Cookies (Safari)" enrollment type corrected from Corporate → Corporate / BYOD

**Section 3.5 (ADM-EXP) cleaned up:**
- Removed 3 rows that were CIS deviations (already in 3.1), not ADM-EXP: "Numeric Passcode Allowed", "Force Automatic Date and Time (not enforced)", "Allow Writing Tools (CIS deviation)"

**Documentation updated:** iOS_CIS-Microsoft_Recommended_Settings_Guide.md (v1.2), README.md (Last Updated → June 2026, filename fix), PROJECT.md, CLAUDE.md

---

### Session 1 (4e3811b6) — May 4 2026
- Established the full 35+ policy list with granular grouping strategy
- Agreed on "Device Security" as the Scope Setting name (over "Core Security")
- Updated compliance policy type from COMP to CP (README is authoritative)
- Analyzed all 7 exported policies from Other iOS Policy Configurations\
- Researched CIS iOS 26 v1.0.0 via Tenable public audit database
- Added Shared iPad (Section 15) and Kiosk (Section 16) to CIS guide (v3.1)
- Added EU DMA block policy
- Updated README.md with all new policy types, deployment models, naming convention
- Session lost due to Zed application update/restart at 4.5MB context

### Session 4 — May 6 2026

**Phase 3 — Compliance redesign, ACP fixes, APP merge:**

**Compliance policy model change (flat model — L1/L2/L3 tiers removed):**
- Removed: L1 Corporate, L2 Corporate, L3 Corporate, L1 BYOD, L2 BYOD, L1 Shared (6 files)
- Added: Corporate, MDE Corporate, BYOD, MDE BYOD, Shared Devices (5 files)
- Model: one base policy (passcode/OS/jailbreak) + one MDE-only policy per device track, both assigned to same group
- MDE threshold: Low (corporate, MDE Corporate policy), Medium (BYOD, MDE BYOD policy)

**App Configuration Policy fixes (import failures):**
- Root cause: original Defender Corporate ACP used `iosManagedDeviceMobileAppConfiguration` with bundleId — Intune cannot link this to an app in the catalog (missing App error)
- Fix: converted Defender Corporate to `iosMobileAppConfiguration` format with tenant GUID `50a78c17-ad84-4b43-b7d3-2a281675776a`
- Added `targetedMobileApps@odata.type`, `#CustomRefTargetedApps`, and `appConfigKeyType@odata.type` per-setting to match Intune export format
- Added 5 new ACP files exported from Intune: Edge, OneDrive, Teams, Outlook (all iosMobileAppConfiguration), Authenticator SDM
- Defender BYOD displayName corrected (was "MDE App Configuration - BYOD Devices")
- Authenticator SDM displayName corrected (removed "- Shared Devices" suffix)
- NOTE: Authenticator SDM still uses `iosManagedDeviceMobileAppConfiguration` + bundleId — will have same import issue as original Defender. Pending tenant GUID for Microsoft Authenticator from user.

**App Protection Policy merge:**
- Removed: L2 BYOD file (separate)
- Remaining: single file — `iOS_iPadOS - APP - USR - App Protection - MAM - L2 - BYOD Devices.json`
- Contains L2 settings (Genmoji block, screen capture block, Edge restriction, etc.)
- Target: allCoreMicrosoftApps (11 apps)

**Total file count change:** 45 → 48 (CP: 6→5, APP: 2→1, ACP: 2→7; net +3)

**Documentation updated in this session:** SETTINGSOUTPUT.md, README.md, memory/project_ios_baseline_complete.md

### Session 5 — May 13 2026

**Phase 4 — Kiosk and Shared iPad removed; 3 BYOD SC policies added:**

- Deleted: `iOS_iPadOS - SC - DEV - Kiosk - Multi App Mode - Corporate Devices.json`
- Deleted: `iOS_iPadOS - SC - DEV - Kiosk - Single App Mode - Corporate Devices.json`
- Deleted: `iOS_iPadOS - SC - DEV - Shared iPad - Corporate Devices.json`
- Created: `iOS_iPadOS - SC - DEV - Apple Intelligence & Siri - BYOD Devices.json` (CIS 2.9.1–2.9.4 — AI controls for BYOD)
- Created: `iOS_iPadOS - SC - DEV - iCloud & Storage - BYOD Devices.json` (CIS 2.2.1.2–2.2.1.3 — encrypted backup, managed cloud sync)
- Created: `iOS_iPadOS - SC - DEV - Device Privacy - BYOD Devices.json` (CIS 2.2.1.4, 2.2.1.11 — advertising, diagnostic, mail privacy)
- SC count: 24 → 21 (removed 3, added 3). Total JSON: 41 → 38.
- Removed all "Shared iOS Devices" and "Kiosk" terminology from all .md files; replaced with SDM-specific language where applicable.
- Removed ADE-iPadOS-SharedIPad and ADE-iOS-Kiosk ADE profile references from deployment guides.
- Updated README.md "What This Baseline Provides" table to list all 8 deliverable types.

**Documentation updated:** README.md, SETTINGSOUTPUT.md, PROJECT.md, iOS_CIS_Recommended_Settings_Guide.md, iOS_iPadOS_MDM_Deployment_Playbook.md, memory/project_ios_baseline_complete.md, MEMORY.md

### Session 6 — May 13 2026

**Shared Device and Kiosk Mode reference guide added:**

- Created: `iOS_iPadOS_Deployment_Guides/iOS_iPadOS_Shared_Device_Kiosk_Guide.md`
- Reference-only guide — no JSON policy files created or modified
- Covers four optional deployment scenarios: Entra Shared Device Mode (frontline), Apple Shared iPad, Single-App Kiosk, Multi-App Kiosk
- Documents conflicts between existing baseline SC policies and each scenario, with group exclusion and override remediation steps
- Added guide reference to README.md Guide Reading Order (entry #6) and Repository Structure
- Corrected Authenticator ACP display name in guide (from `Microsoft Authenticator SDM - Authenticator SDM` to `Microsoft Authenticator - Shared Device Mode`)

**Documentation updated:** README.md, PROJECT.md, iOS_iPadOS_Shared_Device_Kiosk_Guide.md

### Session 7 — May 13 2026

**Pre-publication review — guide corrections and APP policy compliance fix:**

Guide corrections applied to `iOS_iPadOS_Shared_Device_Kiosk_Guide.md`:
- Minimum OS for Entra SDM: corrected from iOS/iPadOS 13 to iOS/iPadOS 14 (per Microsoft documentation)
- ADE enrollment profile UI label: corrected to "Enroll with Microsoft Entra ID shared mode" (added "ID")
- Single-App Kiosk template: corrected from "Device features" to "Device restrictions" template (Kiosk section is in Device restrictions, not Device features; Device features is used for Home Screen Layout, SSO extensions, and notifications)
- Edge ACP key: replaced invalid `Disable-Redirect-restricted-sites-to-personal-context` (not a valid managed configuration key) with `com.microsoft.intune.mam.managedbrowser.AllowTransitionOnBlock` (value: false)

APP policy compliance fix:
- `notificationRestriction` corrected from `allow` to `blockOrganizationalData` in `iOS_iPadOS - APP - USR - App Protection - MAM - L1 - BYOD Devices.json`
- This was a genuine Microsoft Security Configuration Framework Level 2 gap (not a documented intentional deviation)
- Prevents corporate email subjects, sender names, and meeting titles from appearing in lock screen notifications
- `allowedInboundDataTransferSources: allApps` and `writingToolsConfigurationState: notBlocked` confirmed as intentional BYOD deviations (documented in README.md); no change required
- Note: `notificationRestriction` was subsequently reverted to `allow` in Session 14 as an intentional BYOD deviation (see Session 14 entry)

**Documentation updated:** iOS_iPadOS_Shared_Device_Kiosk_Guide.md, AppProtection_MAM/iOS_iPadOS - APP - USR - App Protection - MAM - L1 - BYOD Devices.json, SETTINGSOUTPUT.md, README.md, PROJECT.md, memory/project_ios_baseline_complete.md

### Session 9 — May 14 2026

**Phase 7 — Settings audit: gap fills, redundancy removals, placement corrections**

Comprehensive audit of all 24 SC policy settings for correctness, coverage, and semantic placement.

**Gap fills (settings planned or described but missing from JSON):**
- `Data Protection - BYOD`: added `allowcloudprivaterelay`=false (description in both JSON and SETTINGSOUTPUT.md referenced it; JSON had no corresponding setting)

**Redundancies removed:**
- `Data Protection - Corporate`: removed `forceairdropunmanaged`=true (dead code — `allowairdrop`=false already blocks all AirDrop entirely; force-unmanaged can never take effect)
- `Accessibility & Sharing - Corporate`: removed `allowaddinggamecenterfriends`=false (dead code — `allowgamecenter`=false in Apple Services disables Game Center entirely; the friend-adding restriction can never be triggered)

**Placement corrections (semantically relocated):**
- `allowsharedstream`: moved from Data Protection - Corporate to iCloud & Storage - Corporate (iCloud Shared Photo Stream is an iCloud photo sync feature; belongs alongside allowcloudphotolibrary)
- `allowspotlightinternetresults`: moved from Accessibility & Sharing - Corporate to Device Privacy - Corporate (Spotlight internet results sends search queries to Apple — a data privacy concern, not an access/sharing concern)

**Net setting changes:**
- Data Protection - Corporate: -2 (forceairdropunmanaged removed, allowsharedstream moved out)
- Data Protection - BYOD: +1 (allowcloudprivaterelay)
- iCloud & Storage - Corporate: +1 (allowsharedstream moved in)
- Accessibility & Sharing - Corporate: -2 (allowaddinggamecenterfriends removed, allowspotlightinternetresults moved out); now 4 settings
- Device Privacy - Corporate: +1 (allowspotlightinternetresults moved in)

**Documentation updated:** All 6 SC JSON files, SETTINGSOUTPUT.md (6 policy sections), PROJECT.md, memory/project_ios_baseline_complete.md

---

### Session 11 — May 23 2026

**Settings Catalog policy updates — documentation sync:**

User made changes to 10 Settings Catalog JSON policies between sessions. Documentation updated to reflect current JSON state.

**Policy changes documented:**

- Apple Intelligence & Siri BYOD: replaced `intelligencesettings_allowappleintelligencereport=false` with `externalintelligencesettings_allowsignin=true` (intentional: explicitly allow ChatGPT/external AI on personal devices)
- App Management Corporate: added `blockedappbundleids` with 13 Apple app bundle IDs (com.apple.games, com.apple.tips, com.apple.Home, com.apple.freeform, com.apple.journal, com.apple.mobilemail, com.apple.tv, com.apple.iBooks, com.apple.Bridge, com.apple.Fitness, com.apple.Music, com.apple.stocks, com.apple.Health)
- Device Restrictions Corporate: `activationlockallowedwhilesupervised` changed true→false (intentional: IT can reset/reassign without Apple ID); `forceautomaticdateandtime` changed true→false (intentional)
- Device Restrictions BYOD: added 4 settings (allowautounlock=true, allowfingerprintforunlock=true, allowlockscreentodayview=false, allowpassbookwhilelocked=false)
- Device Security Corporate: `requirealphanumeric` changed true→false (intentional: numeric passcode accepted); `maxinactivity` changed 2→1 minute
- Safari Corporate: added safari_newtabstartpage_homepageurl (https://m365.cloud.microsoft/), safari_newtabstartpage_pagetype (0), com.apple.domains_crosssitetrackingpreventionrelaxeddomains (Microsoft auth domains)
- Safari BYOD: removed safari_allowpopups; `allowdisablingfraudwarning` changed false→true (intentional: BYOD users may disable fraud warning); added crosssitetrackingpreventionrelaxeddomains

**JSON description fields updated (5 files):** Apple Intelligence BYOD, Device Restrictions Corporate, Device Security Corporate, Device Restrictions BYOD, Safari BYOD.

**Documentation updated:** SETTINGSOUTPUT.md (8 policy sections), iOS_CIS-Microsoft_Recommended_Settings_Guide.md (7 sections), CLAUDE.md (confirmed IDs, value corrections, Key Decisions), README.md, PROJECT.md, memory/project_ios_baseline_complete.md

---

### Session 18 — May 26 2026

**Defender Corporate ACP retargeted to VPP app; ACP gap review; Authenticator SDM validated:**

- Defender Corporate JSON: `targetedMobileApps[0]` changed from `50a78c17-ad84-4b43-b7d3-2a281675776a` (iosStoreApp) to `5fdbfbb7-028f-4495-9991-8104e4657b83` (iosVppApp); `#CustomRefTargetedApps` updated accordingly
- Authenticator SDM ACP (`sharedDeviceMode=true`): confirmed correct and complete per Kiosk Guide Part A — no additional policy needed
- ACP gap review (13 policies): no critical gaps found against Microsoft documentation or CIS iOS/iPadOS 26 Benchmark v1.0.0; CIS operates at OS/MDM restriction layer only; SSO Extension SC policy makes optional silent-sign-in ACP keys redundant
- Optional future expansion noted: Word/Excel/PowerPoint/OneNote VPP ACPs (IntuneMAMUPN + IntuneMAMAllowedAccountsOnly) — deferred, not a security gap
- Total JSON count unchanged: 44
- User must delete existing Defender Corporate ACP in Intune and reimport using updated JSON; verify VPP app display name matches `Microsoft Defender: Security` before import
- Documentation updated: CLAUDE.md (Defender Corporate ACP note), PROJECT.md

---

### Session 17 — May 26 2026

**Teams, OneDrive, SharePoint ACPs enriched; Defender docs corrected:**

- New policy: `iOS_iPadOS - ACP - DEV - Microsoft Teams - Corporate Devices.json` (VPP GUID: 104dd256-e504-4c25-9bd7-24fd39b150b1; added IntuneMAMAllowedAccountsOnly, AllowedAccounts=REPLACE placeholder; fixed IntuneMAMUPN leading-space bug)
- New policy: `iOS_iPadOS - ACP - DEV - Microsoft OneDrive - Corporate Devices.json` (VPP GUID: 27d89c62-7ef3-4d4b-9ba7-c6a89845e4eb; added IntuneMAMAllowedAccountsOnly, allowedTenantID=REPLACE placeholder, blockPersonalOneDrive=true)
- New policy: `iOS_iPadOS - ACP - DEV - SharePoint - Corporate Devices.json` (VPP GUID: 6dcbb6aa-5829-41ae-af25-d71dc32b779e; added IntuneMAMAllowedAccountsOnly, allowedTenantID=REPLACE placeholder)
- New policy: `iOS_iPadOS - ACP - DEV - SharePoint - BYOD Devices.json` (App Store GUID: b6941db7-fa1b-4475-b483-31bed43bffb4; description added)
- Updated: Teams BYOD, OneDrive BYOD descriptions added
- Defender doc corrections: UserEnrollmentEnabled=true→false (SETTINGSOUTPUT.md Policy 31 and CLAUDE.md note), DefenderDeviceTag=iOS-iPadOS-CORP-MDM→iOS-iPadOS-MDM (Policy 30)
- ACP count: 9 → 13. Total: 40 → 44.
- Documentation updated: SETTINGSOUTPUT.md (Policies 35–44 renumbered; 4 new policy sections added), CLAUDE.md, README.md, PROJECT.md, iOS_App_Configuration_Policy_Guide.md (Section 4 rows added)

---

### Session 16 — May 26 2026

**Edge ACP split into Corporate + BYOD; recommended settings added to both:**

- New policy: `iOS_iPadOS - ACP - DEV - Microsoft Edge - Corporate Devices.json` (App Store app GUID: 5b1994c5-9482-4ad5-baf4-3deee89441b6; added IntuneMAMAllowedAccountsOnly, SmartScreen, CertificateTransparency, CookieBlockingLevel=blockThirdPartyCookies, SearchEngineDefault=Bing, AllowSearchEngineCustomization=false, NewTabPage.CustomURL=m365.cloud.microsoft)
- Expanded: `iOS_iPadOS - ACP - DEV  - Microsoft Edge - BYOD Devices.json` (added SmartScreen, CertificateTransparency, CookieBlockingLevel=blockThirdPartyCookies)
- ACP count: 8 → 9. Total: 39 → 40.
- Documentation updated: SETTINGSOUTPUT.md (Policy 33 Corporate Edge inserted; renumbered 34–40), CLAUDE.md, PROJECT.md, README.md, iOS_App_Configuration_Policy_Guide.md (Section 4 Corporate Edge row added)

---

### Session 15 — May 26 2026

**Outlook ACP split into Corporate + BYOD; App Configuration Policy Guide corrected:**

- New policy: `iOS_iPadOS - ACP - DEV - Outlook Settings - Corporate Devices.json` (VPP app GUID: 90cad2f9-fda9-4e65-af48-c349a2491351; includes IntuneMAMAllowedAccountsOnly, IntuneMAMUPN, contacts sync locked, ExternalRecipientsToolTipEnabled)
- BYOD policy confirmed as Managed Device type (MDM channel; enrolled BYOD only — com.microsoft.outlook.* keys are MDM-channel only and cannot be delivered to MAM-unenrolled devices via any ACP type)
- ACP count: 7 → 8. Total: 38 → 39.
- Documentation updated: iOS_App_Configuration_Policy_Guide.md (type correction, key name AllowExternalRecipientWarning→ExternalRecipientsToolTipEnabled, MDM limitation note, VPP vs App Store note), SETTINGSOUTPUT.md, CLAUDE.md, PROJECT.md, README.md

---

### Session 14 — May 26 2026

**App Protection Policy renamed L1→L2 and notificationRestriction reverted to allow:**

- Renamed: `iOS_iPadOS - APP - USR - App Protection - MAM - L1 - BYOD Devices.json` → `iOS_iPadOS - APP - USR - App Protection - MAM - L2 - BYOD Devices.json`
- `notificationRestriction` changed from `blockOrganizationalData` back to `allow` (intentional BYOD deviation — blocking notifications on personal devices is too disruptive to personal use)
- Three intentional BYOD deviations now documented: (1) inbound from allApps, (2) Writing Tools notBlocked, (3) notifications allowed
- Documentation updated: SETTINGSOUTPUT.md, PROJECT.md, README.md, CLAUDE.md, iOS_iPadOS_BYOD_Deployment_Guide.md

---

### Session 13 — May 2026

**Apple Intelligence & Siri BYOD policy removed — DDM migration incompatibility:**

- Deleted: `iOS_iPadOS - SC - DEV - Apple Intelligence & Siri - BYOD Devices.json`
- Root cause: Microsoft migrated Apple Intelligence settings in Intune from Device Restrictions Configuration to Declarative Device Management (DDM). The new DDM-based settings apply correctly on supervised Corporate devices but produce errors in Intune when assigned to unsupervised BYOD devices. The single setting in the BYOD policy (`externalintelligencesettings_allowsignin=true`) has no supported DDM equivalent for unsupervised devices.
- MAM App Protection Policies already prevent corporate data from being processed by Apple AI within managed apps — no device-level Apple Intelligence control is needed for BYOD.
- SC count: 23 → 22. Total JSON: 39 → 38.
- Documentation updated: SETTINGSOUTPUT.md, README.md, PROJECT.md, CLAUDE.md, iOS_CIS-Microsoft_Recommended_Settings_Guide.md, iOS_iPadOS_BYOD_Deployment_Guide.md, memory files.

---

### Session 12 — May 2026

**MDM Deployment Playbook split into two track-specific guides:**

- Created: `iOS_iPadOS_Corporate_Deployment_Guide.md` — ADE/supervised enrollment end-to-end; Setup Assistant screen table updated (6 screens changed from current ADE profile); Managed Apple ID integration documented as optional add-on in Section 7.6
- Created: `iOS_iPadOS_BYOD_Deployment_Guide.md` — all four BYOD enrollment options, fully self-contained; Stolen Device Protection note retained; enrollment comparison tables and wipe capability matrix included
- Deleted: `iOS_iPadOS_MDM_Deployment_Playbook.md`
- Updated: README.md (Guide Reading Order table, directory listing, cross-references), CLAUDE.md (folder structure count 5→6), PROJECT.md, memory files

**Setup Assistant screen changes documented in Corporate guide Section 7.3 (6 screens updated from current ADE enrollment profile):**
- Location Services: Hide → Show (allows per-app location prompts during initial setup)
- Restore: Show → Hide (ensures clean provisioning state; no personal backup restore on corporate devices)
- Apple ID: Hide → Show (allows Managed Apple ID authentication during OOBE; see Section 7.6)
- Touch ID and Face ID: Hide → Show (biometric setup during provisioning)
- Privacy: Show → Hide (reduces OOBE friction; corporate privacy terms communicated via acceptable use policy)
- Software Update completed: Hide → Show (consistent with Software Update = Show)

**Managed Apple ID integration (Section 7.6 of Corporate guide):** Documented as optional add-on for organizations that restrict personal Apple IDs on corporate devices. Post-provisioning lock-down via `com.apple.applicationaccess_allowaccountmodification=false` in Device Restrictions Corporate policy (already deployed in this baseline — no additional policy required).

---

### Session 10 — May 18 2026

**Phase 8 — Deduplication, structural conflict resolution, and compliance update**

**Gap fills confirmed from Phase 7 recommendations (settings exported from Intune as present):**
- `Device Security - Corporate`: `allowpasswordautofill`=false, `allowpasswordproximityrequests`=false, `allowpasswordsharing`=false, `forceauthenticationbeforeautofill`=true — added by user between sessions
- `Connectivity Controls - Corporate`: `allowappcellulardatamodification`=false, `allowesimmodification`=false, `allowesimoutgoingtransfers`=false — added by user between sessions
- `Web-App-Store (EU) - Corporate`: `allowmarketplaceappinstallation`=false, `allowwebdistributionappinstallation`=false — added by user between sessions; new policy
- `Device Restrictions - BYOD`: new policy added by user — 5 settings (lock screen notifications, lock screen control center, untrusted TLS, activity continuation, watch wrist detection)

**Duplicates removed:**
- `allowpasswordproximityrequests`, `allowpasswordsharing`, `forceauthenticationbeforeautofill` removed from `Device Restrictions - Corporate` — duplicate of settings in `Device Security - Corporate`; `Device Security` is the authoritative home for all password/authentication settings
- `allowaddinggamecenterfriends` removed from `Device Restrictions - Corporate` — logically redundant when `allowgamecenter`=false is in `Apple Services - Corporate` (Game Center fully disabled)

**Structural conflict resolved:**
- `settings_item_mdmoptions` group with `idlerebootallowed`=true was present in both `Software Update - Corporate` (id=2) and `Device Restrictions - Corporate` (id=0) — Intune reports a conflict when the same group wrapper is applied by two policies to the same device
- Resolution: removed the standalone `settings_item_mdmoptions` group from `Software Update - Corporate`; added `idlerebootallowed`=true as a second child alongside `activationlockallowedwhilesupervised`=true in `Device Restrictions - Corporate`'s existing mdmoptions group
- `Software Update - Corporate` settingCount updated from 3 to 2

**Policy rename (Intune-side, reflected in file exports):**
- `Device Administration - Corporate Devices` renamed to `Device Restrictions - Corporate Devices` in Intune; file export and all documentation updated accordingly

**Description fields updated:** Device Restrictions Corporate, Software Update Corporate, Device Security Corporate, Connectivity Controls Corporate

**Documentation updated:** SETTINGSOUTPUT.md (Policy 10, 11, 14, 23, summary table, compliance assessment section added), PROJECT.md (this entry, header, policy table row 9)

---

### Session 8 — May 14 2026

**Phase 5 — Device Restrictions Corporate split; Device Settings renamed; description fields updated:**

**Rationale for split:** `Device Restrictions - Corporate Devices.json` contained 29 settings across 6 distinct behavioral categories in a single flat policy, making it difficult for an administrator to identify which setting is causing an issue without scanning the entire policy.

**Files deleted:**
- `SettingsCatalog\iOS_iPadOS - SC - DEV - Device Restrictions - Corporate Devices.json` (29 settings distributed to 4 new policies)

**Files created (4 new SC policies):**
- `SettingsCatalog\iOS_iPadOS - SC - DEV - App Management - Corporate Devices.json` — 8 settings: app installation, removal, automatic downloads, App Clips, in-app purchases, enterprise app trust, system app removal, UI app installation
- `SettingsCatalog\iOS_iPadOS - SC - DEV - Connectivity Controls - Corporate Devices.json` — 8 settings: Personal Hotspot (separate MDM payload), Bluetooth, NFC, cellular plan, hotspot modification, VPN creation, forced Wi-Fi power on, untrusted TLS certificate prompts
- `SettingsCatalog\iOS_iPadOS - SC - DEV - Device Administration - Corporate Devices.json` — 8 settings: account modification, default browser, device name, enabling restrictions, erase content, notifications modification, config profile installation, automatic date/time
- `SettingsCatalog\iOS_iPadOS - SC - DEV - Accessibility & Sharing - Corporate Devices.json` — 4 settings: remote screen observation, Handoff, iPhone Mirroring, iPhone Widgets on Mac (renamed from Sharing & Pairing; Phase 6; allowaddinggamecenterfriends and allowspotlightinternetresults removed in Phase 7)

**Files renamed:**
- `iOS_iPadOS - SC - DEV - Device Settings - Corporate Devices.json` → `iOS_iPadOS - SC - DEV - Device Accessories - Corporate Devices.json` (Phase 5)
- `iOS_iPadOS - SC - DEV - Device Accessories - Corporate Devices.json` → `iOS_iPadOS - SC - DEV - Device Pairing - Corporate Devices.json` (Phase 6; absorbed host pairing, proximity setup, USB Restricted Mode from Accessibility & Sharing; 3 → 6 settings)

**Description fields updated:** All 24 SC JSON files — descriptions now enumerate specific setting categories for Intune portal visibility and administrator triage.

**SC file count:** 21 → 24
**JSON total:** 37 → 40

**Documentation updated:** SETTINGSOUTPUT.md (4 new policy sections, all 38 policy numbers updated, summary table, Implementation Order table), README.md (SC count, file list, policy reference count), PROJECT.md (this entry), memory/project_ios_baseline_complete.md, memory/MEMORY.md

### Session 3 — May 5 2026

**Folder renames (user-initiated):**
- `DefenderForEndpoint\` renamed to `DeviceConfiguration_DefenderForEndpoint\`
- `AppConfigurationManagedDevice\` renamed to `AppConfiguration_ManagedDevice\`

**New folders (user-initiated):**
- `ConditionalAccess\` — 2 CA policy JSON files (CA-User-Protection-AllUsers-AllApps-iOS-Req-ComplianceDevice requires compliantDevice; CA-User-Protection-AllUsers-O365-MobileApps-iOS-Req-AppProtectionPolicy-BYOD requires compliantApplication for BYOD)
- `iOS_iPadOS_Deployment_Guides\` — 5 .md deployment reference guides

**Phase 2 refactoring — L1/L2/L3 additive-only model:**
- L2/L3 Settings Catalog policies now contain only settings not in lower tiers (eliminates Intune conflict on same-key settings)
- Device Security L2 Corporate: Removed `minlength` and `maxinactivetime` (handled by L2 Compliance Policy)
- Device Security L3 Corporate: Removed `requirealphanumericvalue` (already in L2); `maxpinfailures`=5 kept in L3 only (no compliance equivalent)
- Device Security L1 Corporate: Removed `maxpinfailures`=6 (moved to L3; L1-only devices use device default)
- Device Security L2 BYOD: Description corrected (JSON already clean — no `minlength` present)
- Compliance L2 Corporate: Removed redundant fields with same value as L1 (`passcodeRequired`, `passcodeBlockSimple`, `securityBlockJailbrokenDevices`, `storageRequireEncryption`)
- Compliance L3 Corporate: Stripped to single unique field (`advancedThreatProtectionRequiredSecurityLevel=clear`) + scheduled action
- Compliance L2 BYOD: Removed same 4 redundant fields; removed `managedEmailProfileRequired=false` (same as L1 BYOD)

**Phase 3 — Apple Intelligence policy split:**
- Deleted: `iOS_iPadOS - SC - DEV - Apple Intelligence - All Devices.json`
- Created: `iOS_iPadOS - SC - DEV - Apple Intelligence - L1 - All Devices.json` (4 CIS L1 controls: Writing Tools, External Intelligence Extensions, Notes Summarization, Mail Summarization)
- Created: `iOS_iPadOS - SC - DEV - Apple Intelligence - L2 - All Devices.json` (5 additional controls: Genmoji, Image Playground, Image Wand, Personalized Handwriting, Safari History Clearing)
- Total SettingsCatalog count: 30 → 31

**Documentation updated:** README.md (BYOD enrollment types, additive model, version history), PROJECT.md
**BYOD enrollment research:** Documented web-based device enrollment vs account-driven user enrollment in README.md

### Session 2 (34155c33) — May 4 2026
- Recovered all prior session work from transcript file
- Re-read all source files: CIS guide all sections, App Protection guide, App Configuration guide, all 7 exported JSON policies, SSO JSON, Software Update benchmark JSON
- Updated plan file with complete 42-policy list, all settings values, all settingDefinitionIds, MAM L1/L2 settings, Shared iPad and Kiosk details, ACP key-value pairs
- Added SETTINGSOUTPUT.md requirement per user request
- Session interrupted multiple times during plan approval

## 3. Key Decisions Log

| Decision | Value | Reason |
|---|---|---|
| Scope Setting name | Device Security | Agreed over "Core Security" in session 1 |
| Compliance policy type | CP | README created after plan — README is authoritative over COMP |
| MDE Control Filter type | Custom | CP = Compliance Policy in our convention — naming conflict with original file |
| MDE VPN type | VPN | Original file used DC — not correct in our convention |
| SSO policy type | SC | Settings Catalog, not Device Configuration template |
| Notifications policy | Separate file (#29) | Kept as standalone, not folded into Device Security |
| Web Content Filter policy | Separate file (#30) | Kept as standalone supervised-only L2 policy |
| Software update deferral | 14 days | Our guide recommendation (existing file uses 7 days — both valid) |
| Install time | 02:00 | Overnight maintenance window (benchmark file uses 03:00) |
| Grace Period Before Lock | Immediately | CIS iOS 26 promoted from L2 to L1 for both Corporate and BYOD |
| Block Handoff | L1 | CIS iOS 26 promoted from L2 to L1 |
| Block Diagnostic Data | L1 | CIS iOS 26 promoted from L2 to L1 |
| Block Control Center on Lock Screen | L1 | CIS iOS 26 promoted from L2 to L1 |
| Block iCloud Drive | L1 Corporate | CIS iOS 26 promoted from L2 to L1 |
| Managed Web Domains | L1 | CIS iOS 26 promoted from L2 to L1 for all devices |
| Allow Installing Config Profiles | L1 (new) | New CIS iOS 26 L1 control |
| Apple Intelligence | L1 (new) | 4 new CIS iOS 26 L1 controls |
| Folders to delete after implementation | Apple iOS Benchmarks\, Other iOS Policy Configurations\ | Content migrated to grouped policies |
| L1/L2/L3 assignment model | Additive-only | L2 assigned on top of L1; L3 on top of L1+L2; each tier contains only unique settings |
| maxpinfailures | L3 only (Settings Catalog) | No compliance equivalent; L1-only devices use device default (6); conflict avoided by removing from L1 |
| Apple Intelligence policy | Split into L1 and L2 | L1 = 4 CIS mandatory controls; L2 = 5 additional UX-impact controls |
| BYOD enrollment type | Web-based device enrollment assumed | All BYOD policies target full-device enrollment; account-driven user enrollment uses MAM only |

## 4. Exported Policy Analyses (Other iOS Policy Configurations)

### iOS - Managed - DDM - Software Updates.json
- Type: Settings Catalog (deviceManagementConfigurationPolicy) — correct approach for iOS 26+
- Settings: Auto-download and auto-install enabled, 7-day deferral, RSR enabled with rollback, Recommendation cadence major releases (value 2)
- Action: Keep, adapt. Change deferral to 14 days, install time to 02:00
- Rename to: iOS_iPadOS - UP - DEV - Software Update - Corporate Devices.json

### iOS_Disable Web Distribution App Installation EU.json
- Type: Settings Catalog
- Settings: Blocks alternative app marketplace installation (EU DMA compliance)
- Action: Keep standalone. EU organizations only. Do not fold into main L1 policy.
- Rename to: iOS_iPadOS - SC - DEV - Block Web Distribution Install - EU - Corporate Devices.json

### iOS_iPadOS - SC - DEV - Microsoft Enterprise SSO.json
- Type: Settings Catalog (com.apple.extensiblesso prefix)
- Settings: Extension com.microsoft.azureauthenticator.ssoextension, AppPrefixAllowList com.microsoft.,com.apple., browser_sso_interaction_enabled=1, disable_explicit_app_prompt=1, device_registration={{DEVICEREGISTRATION}}, 7 Microsoft login URLs
- Action: Keep, rename only. Deploy before all other policies. Deploy to all devices (supervised and BYOD).
- Rename to: iOS_iPadOS - SC - DEV - Microsoft Enterprise SSO - All Devices.json

### iOS_iPadOS_Shared iPad.json
- Type: Settings Catalog
- Settings: Allow Network Drive Access, Allow Shared Device Temporary Session, Force Auto Date/Time, Force WiFi to Allowed Networks Only
- Action: Keep, adapt. Add Maximum Temporary Session Timeout (900s), Maximum User Session Timeout (28800s). Deploy on top of L1 Corporate.
- Rename to: iOS_iPadOS - SC - DEV - Shared iPad - Shared Devices.json

### iOS_[SWC] - Baseline Device Restrictions.json
- Type: iosGeneralDeviceConfiguration (LEGACY TEMPLATE FORMAT — not Settings Catalog)
- Three critical bugs found:
  - usbRestrictedModeBlocked: true — means USB Restricted Mode is BLOCKED = USB accessories ALLOWED after screen lock. Should be false to ENABLE restricted mode (block accessories). This is opposite of CIS L1 intent.
  - safariBlockAutofill: false — Safari AutoFill is NOT blocked. Should be true.
  - activationLockAllowWhenSupervised: false — Activation Lock is disabled on supervised devices. Should be true.
- Additional settings not yet in CIS guide: managedPasteboardRequired: true, esimBlockModification: true, gameCenterBlocked: true, gamingBlockMultiplayer: true, spotlightBlockInternetResults: true
- Action: Do NOT fold in as-is. RETIRE this policy after migration to Settings Catalog. New baseline handles all settings correctly.

### iOS_iPadOS - CP - DEV - Zero-Touch-Control-Filter - MDE - Supervised (Corporate-Owned).json
- Type: iosCustomConfiguration (base64 .mobileconfig payload)
- Settings: com.apple.webcontentfilter payload, com.microsoft.scmx plugin, delivers web protection via network extension (no local VPN on supervised)
- Naming conflict: CP in this name means "Custom Profile" but CP = Compliance Policy in our convention
- Action: Keep payload unchanged, update display name only.
- Renamed to: iOS_iPadOS - CP - DEV - Zero-Touch-Control-Filter - MDE - Corporate Devices.json

### iOS_iPadOS - DC - DEV - Zero-Touch-Onboarding - MDE - Unsupervised (Personal BYOD).json
- Type: iosVpnConfiguration
- Settings: Connection type customVpn, identifier com.microsoft.scmx, server 127.0.0.1 (local loopback — traffic does not leave device), SilentOnboard: True, SingleSignOn: True, On-demand connect, disableOnDemandUserOverride: true
- Action: Keep unchanged, update display name only.
- Renamed to: iOS_iPadOS - DC - DEV - Zero-Touch-Onboarding-VPN - MDE - BYOD Devices.json

## 5. Naming Convention

Format: iOS_iPadOS - {PolicyType} - {DEV|USR} - {ScopeSetting} - {L1|L2|L3} - {Device Type}

Rules:
- Layer (L1/L2/L3) omitted for standalone policies: Software Update, Apple Intelligence, Lock Screen Message, SSO, EU Block
- MAM only appears in APP policy names
- Device Type values: Corporate Devices, BYOD Devices, All Devices

| Policy Type Code | Full Name | @odata.type | Graph Endpoint |
|---|---|---|---|
| SC | Settings Catalog | #microsoft.graph.deviceManagementConfigurationPolicy | deviceManagement/configurationPolicies |
| UP | Update Policy (DDM) | #microsoft.graph.deviceManagementConfigurationPolicy | deviceManagement/configurationPolicies |
| CP | Compliance Policy | #microsoft.graph.iosCompliancePolicy | deviceManagement/deviceCompliancePolicies |
| APP | App Protection Policy | #microsoft.graph.iosManagedAppProtection | deviceManagement/managedAppPolicies |
| ACP (Managed Devices) | App Configuration — MDM | #microsoft.graph.iosMobileAppConfiguration | deviceManagement/mobileAppConfigurations |
| VPN | VPN Profile | #microsoft.graph.iosVpnConfiguration | deviceManagement/deviceConfigurations |
| Custom | Custom .mobileconfig | #microsoft.graph.iosCustomConfiguration | deviceManagement/deviceConfigurations |

All JSON files use: platforms: "iOS", technologies: "mdm,appleRemoteManagement", assignments: [], roleScopeTagIds: ["0"]

## 6. settingDefinitionId Reference

Sources (in priority order):
1. Apple iOS Benchmarks\ folder — validated IDs (read before deleting)
2. Other iOS Policy Configurations\ folder — production validated policies
3. Pattern: {com.apple.domain}_{payloadkey} all lowercase

Known prefixes:
- com.apple.applicationaccess_ (restrictions)
- com.apple.mobiledevice.passwordpolicy_ (passcode)
- com.apple.safari_ (Safari)
- com.apple.icloud_ (iCloud)
- ddm-latestsoftwareupdate_ (Software Update DDM)
- com.apple.extensiblesso_ (SSO Extension)
- com.apple.webcontent-filter_ (Web Content Filter)
- com.apple.notifications_ (Notifications)

Confirmed IDs from existing files:

Software Update (DDM):
- ddm-latestsoftwareupdate_ddm-latestsoftwareupdate (group wrapper)
- ddm-latestsoftwareupdate_enforcelatestsoftwareupdateversion (choice)
- ddm-latestsoftwareupdate_enforcelatestsoftwareupdateversion_0 (enforce latest value)
- ddm-latestsoftwareupdate_delayindays (integer — use 14)
- ddm-latestsoftwareupdate_installtime (string — use "02:00")

SSO Extension:
- com.apple.extensiblesso_com.apple.extensiblesso (group wrapper)
- com.apple.extensiblesso_extensiondata (data collection)
- com.apple.extensiblesso_extensiondata_generickey_keytobereplaced (key name)
- com.apple.extensiblesso_extensiondata_generickey_string (string value)
- com.apple.extensiblesso_extensiondata_generickey_integer (integer value)
- com.apple.extensiblesso_ignored_$typepicker (type selector)
- com.apple.extensiblesso_extensionidentifier (extension bundle ID)
- com.apple.extensiblesso_screenlockedbehavior (behavior when locked)
- com.apple.extensiblesso_type (credential type)
- com.apple.extensiblesso_urls (URL collection)

Rapid Security Response:
- com.apple.applicationaccess_allowrapidsecurityresponseinstallation
- com.apple.applicationaccess_allowrapidsecurityresponseremoval

## 7. Complete Policy List — 38 Files

### Category: Settings Catalog — SettingsCatalog\

Flat-named policies (no L1/L2/L3 suffix). All 22 files are in scope for the baseline.

| # | File Name | Target | Notes |
|---|---|---|---|
| 1 | iOS_iPadOS - SC - DEV - Apple Intelligence & Siri - Corporate Devices.json | ADE/Supervised | CIS 3.10.x; do not assign to BYOD |
| 2 | iOS_iPadOS - SC - DEV - Apple Services - Corporate Devices.json | ADE/Supervised | |
| 4 | iOS_iPadOS - SC - DEV - App Management - Corporate Devices.json | ADE/Supervised | |
| 5 | iOS_iPadOS - SC - DEV - Connectivity Controls - Corporate Devices.json | ADE/Supervised | |
| 6 | iOS_iPadOS - SC - DEV - Data Protection - Corporate Devices.json | ADE/Supervised | |
| 7 | iOS_iPadOS - SC - DEV - Data Protection - BYOD Devices.json | BYOD | |
| 8 | iOS_iPadOS - SC - DEV - Device Pairing - Corporate Devices.json | ADE/Supervised | |
| 9 | iOS_iPadOS - SC - DEV - Device Restrictions - Corporate Devices.json | ADE/Supervised | |
| 10 | iOS_iPadOS - SC - DEV - Device Privacy - Corporate Devices.json | ADE/Supervised | |
| 11 | iOS_iPadOS - SC - DEV - Device Privacy - BYOD Devices.json | BYOD | |
| 12 | iOS_iPadOS - SC - DEV - Device Restrictions - BYOD Devices.json | BYOD | |
| 13 | iOS_iPadOS - SC - DEV - Device Security - Corporate Devices.json | ADE/Supervised | |
| 14 | iOS_iPadOS - SC - DEV - Device Security - BYOD Devices.json | BYOD | |
| 15 | iOS_iPadOS - SC - DEV - iCloud & Storage - Corporate Devices.json | ADE/Supervised | |
| 16 | iOS_iPadOS - SC - DEV - iCloud & Storage - BYOD Devices.json | BYOD | |
| 17 | iOS_iPadOS - SC - DEV - Lock Screen - Corporate Devices.json | ADE/Supervised | Replace placeholder text before import |
| 18 | iOS_iPadOS - SC - DEV - Microsoft Enterprise SSO - All Devices.json | All Enrolled | Deploy FIRST |
| 19 | iOS_iPadOS - SC - DEV - Accessibility & Sharing - Corporate Devices.json | ADE/Supervised | |
| 20 | iOS_iPadOS - SC - DEV - Safari Browser - Corporate Devices.json | ADE/Supervised | |
| 21 | iOS_iPadOS - SC - DEV - Safari Browser - BYOD Devices.json | BYOD | |
| 22 | iOS_iPadOS - SC - DEV - Software Update - Corporate Devices.json | ADE/Supervised | DDM; mandatory iOS 26+ |
| 23 | iOS_iPadOS - SC - DEV - Web-App-Store (EU) - Corporate Devices.json | EU Only | EU DMA compliance |

### Category: Compliance Policies — CompliancePolicies\

Flat model: one base policy + one MDE-only policy per track. Both assigned to the same device group. Intune evaluates each independently.

| # | File Name | Type | Target |
|---|---|---|---|
| 25 | iOS_iPadOS - CP - DEV - Compliance - Corporate Devices.json | Base | ADE/Supervised |
| 26 | iOS_iPadOS - CP - DEV - Compliance - MDE - Corporate Devices.json | MDE | ADE/Supervised |
| 27 | iOS_iPadOS - CP - DEV - Compliance - BYOD Devices.json | Base | BYOD |
| 28 | iOS_iPadOS - CP - DEV - Compliance - MDE - BYOD Devices.json | MDE | BYOD |

### Category: App Protection MAM — AppProtection_MAM\

Single L2 policy (Enterprise Enhanced Data Protection).

| # | File Name | Target |
|---|---|---|
| 29 | iOS_iPadOS - APP - USR - App Protection - MAM - L2 - BYOD Devices.json | allCoreMicrosoftApps (11 apps) / BYOD users |

### Category: App Configuration — AppConfiguration_ManagedDevice\

| # | File Name | odata.type | Target |
|---|---|---|---|
| 30 | iOS_iPadOS - ACP - DEV - Microsoft Defender - Corporate Devices.json | iosMobileAppConfiguration | ADE/Supervised — MDM channel |
| 31 | iOS_iPadOS - ACP - DEV - Microsoft Defender - BYOD Devices.json | iosMobileAppConfiguration | BYOD — MDM channel |
| 32 | iOS_iPadOS - ACP - DEV - Microsoft Authenticator - Shared Device Mode.json | iosMobileAppConfiguration | Entra SDM Shared Devices |
| 33 | iOS_iPadOS - ACP - DEV - Microsoft Edge - Corporate Devices.json | iosMobileAppConfiguration | Corporate |
| 34 | iOS_iPadOS - ACP - DEV  - Microsoft Edge - BYOD Devices.json | iosMobileAppConfiguration | BYOD |
| 35 | iOS_iPadOS - ACP - DEV - Microsoft OneDrive - Corporate Devices.json | iosMobileAppConfiguration | Corporate |
| 36 | iOS_iPadOS - ACP - DEV - Microsoft OneDrive - BYOD Devices.json | iosMobileAppConfiguration | BYOD |
| 37 | iOS_iPadOS - ACP - DEV - Microsoft Teams - Corporate Devices.json | iosMobileAppConfiguration | Corporate |
| 38 | iOS_iPadOS - ACP - DEV - Microsoft Teams - BYOD Devices.json | iosMobileAppConfiguration | BYOD |
| 39 | iOS_iPadOS - ACP - DEV - SharePoint - Corporate Devices.json | iosMobileAppConfiguration | Corporate |
| 40 | iOS_iPadOS - ACP - DEV - SharePoint - BYOD Devices.json | iosMobileAppConfiguration | BYOD |
| 41 | iOS_iPadOS - ACP - DEV - Outlook Settings - Corporate Devices.json | iosMobileAppConfiguration | Corporate |
| 42 | iOS_iPadOS - ACP - DEV - Outlook Settings - BYOD Devices.json | iosMobileAppConfiguration | BYOD |

Policy 32 (Authenticator SDM) uses bundleId format — replace with tenant GUID for Microsoft Authenticator before import.

### Category: Defender for Endpoint — DeviceConfiguration_DefenderForEndpoint\

| # | File Name | Type | Target |
|---|---|---|---|
| 43 | iOS_iPadOS - CP - DEV - Zero-Touch-Control-Filter - MDE - Corporate Devices.json | iosCustomConfiguration | ADE/Supervised |
| 44 | iOS_iPadOS - DC - DEV - Zero-Touch-Onboarding-VPN - MDE - BYOD Devices.json | iosVpnConfiguration | BYOD |

### Category: Conditional Access — ConditionalAccess\

Import via Entra portal, not IntuneManagement-Master. Environment-specific exclusion group GUIDs must be replaced before import.

| # | File Name | Grant Control | Target |
|---|---|---|---|
| 40 | CA-User-Protection-AllUsers-AllApps-iOS-Req-ComplianceDevice.json | compliantDevice | Enrolled iOS |
| 41 | CA-User-Protection-AllUsers-O365-MobileApps-iOS-Req-AppProtectionPolicy-BYOD.json | compliantApplication | O365 mobile apps BYOD |

## 8. Settings Reference

For complete per-policy settings details, see `SETTINGSOUTPUT.md`. That file documents all 39 device management policies and 2 Conditional Access policies with full settings tables, values, and implementation order guidance.

